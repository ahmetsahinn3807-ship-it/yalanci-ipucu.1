package com.yalanciipucu.oyun;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#13202B"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // ilerleme kaydı için
        s.setAllowFileAccess(true);            // assets içindeki oyun ve yazı tipleri
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);                    // telefonun yazı boyutu ayarı sayfayı bozmasın
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new TtsBridge(), "AndroidTTS");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("tr", "TR"));
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(0.95f);
            }
        });

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Oyundaki "sesli oku" düğmeleri bu köprüyü kullanır. */
    private class TtsBridge {
        @JavascriptInterface
        public void speak(String text) {
            if (ttsReady && text != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yi");
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Önce oyun içinde bir önceki ekrana dön; ana ekrandaysak uygulamadan çık.
        web.evaluateJavascript("(window.yiBack && window.yiBack()) ? 'ok' : 'exit'", value -> {
            if (value == null || value.contains("exit")) finish();
        });
    }

    @Override
    protected void onPause() {
        if (tts != null) tts.stop();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
