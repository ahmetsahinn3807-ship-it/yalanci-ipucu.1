# Yalancı İpucu

Her seviyede ipuçlarından biri yalan söyler. Oyuncu hem yalancı ipucunu hem de doğru cevabı bulur.

- 4 yaş modu: Minik Dedektif (4–7), Dedektif (8–12), Usta (13+), Sakin Mod (büyük yazı)
- 160 seviye ve her gün yeni bir "Günün bulmacası"
- 3 bulmaca türü: hazine kutuları, kim yaptı, yarış sırası
- Her seviye bir çözücüden geçer; tek çözümü ve doğru sayıda yalancısı olmayan seviye oyuna girmez
- İnternet izni yok, reklam yok, veri toplamaz; ilerleme telefonda saklanır
- Minik modda ipuçları telefonun Türkçe sesiyle okunur

## APK nasıl üretilir?

Proje, GitHub'a yüklendiğinde APK'yı kendisi derler. Bilgisayar gerekmez.

1. GitHub'da yeni ve boş bir depo aç (ör. `yalanci-ipucu`).
2. Bu klasörün içeriğini depoya yükle. `.github` klasörünün de yüklendiğinden emin ol.
3. Deponun **Actions** sekmesinde "APK üret" işi başlar ve birkaç dakika sürer.
4. İş bitince deponun **Releases** bölümünde `yalanci-ipucu-1.apk` dosyası belirir. Telefondan indir ve kur.
   Android "bilinmeyen kaynaklardan yükleme" izni isteyebilir; bu izni yalnızca bu kurulum için ver.

Sonraki her değişiklikte yeni bir sürüm numarasıyla yeni APK oluşur.

## Oyunu değiştirmek

- Oyun kodu: `oyun/src/index.html` (ekranlar) ve `oyun/src/engine.js` (bulmaca üreteci ve çözücü)
- Değişiklikten sonra `python3 oyun/build.py` komutu sayfayı `app/src/main/assets` içine kopyalar.
  GitHub'daki iş bunu zaten otomatik yapar.

## Play Store'a çıkmadan önce

- Şu anki APK test anahtarıyla imzalı; telefona kurmak için yeterli ama Play Store kabul etmez.
  Mağaza için kendi yükleme anahtarını oluşturup `.aab` paketi üretmek gerekir.
- Play Store'un istediği `targetSdk` sürümü her yıl yükselir; yayından önce güncel şartı kontrol et.
- Çocuklara yönelik uygulamalar için Google Play aile politikası ve KVKK gerekliliklerine bir uzmanla bak.

Yazı tipleri (Patrick Hand, Baloo 2, Nunito) SIL Open Font License ile dağıtılır ve derleme sırasında eklenir.
