#!/usr/bin/env python3
"""oyun/src klasöründen iki çıktı üretir:
- oyun/dist/web/index.html        : motor gömülü tek dosya (tarayıcıda oynamak için)
- app/src/main/assets/index.html  : aynı sayfa, tam HTML iskeletiyle (APK içindeki WebView için)
Oyunu değiştirdikten sonra: python3 oyun/build.py
"""
import pathlib

root = pathlib.Path(__file__).parent
src = (root / 'src' / 'index.html').read_text(encoding='utf-8')
engine = (root / 'src' / 'engine.js').read_text(encoding='utf-8')
inlined = src.replace('<script src="engine.js"></script>', '<script>\n' + engine + '\n</script>')
assert inlined != src, 'engine etiketi bulunamadı'

web = root / 'dist' / 'web'
web.mkdir(parents=True, exist_ok=True)
(web / 'index.html').write_text(inlined, encoding='utf-8')

head_end = inlined.index('</style>') + len('</style>')
android = ('<!doctype html>\n<html lang="tr">\n<head>\n<meta charset="utf-8">\n'
           '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
           '<style>@font-face{font-family:"Patrick Hand";src:url(fonts/PatrickHand-Regular.ttf)}'
           '@font-face{font-family:"Baloo 2";src:url(fonts/Baloo2.ttf);font-weight:400 800}'
           '@font-face{font-family:"Nunito";src:url(fonts/Nunito.ttf);font-weight:200 1000}'
           '[hidden]{display:none!important}:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}</style>\n'
           + inlined[:head_end] + '\n</head>\n<body>\n' + inlined[head_end:] + '\n</body>\n</html>\n')
for asset in (root.parent / 'app' / 'src' / 'main' / 'assets',):
    asset.mkdir(parents=True, exist_ok=True)
    (asset / 'index.html').write_text(android, encoding='utf-8')
print('ok', len(inlined), len(android))
