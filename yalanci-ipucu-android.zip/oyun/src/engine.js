/* Yalancı İpucu — bulmaca motoru
 * Her seviye: aday dünyalar + ipuçları. Kural: tam L ipucu yalan.
 * Geçerli seviye: tam L yanlış ipucuna sahip TEK dünya var ve hiçbir dünyada L'den az yanlış yok.
 */
(function (root) {
  'use strict';

  // ---------- Rastgelelik (tohumlu) ----------
  function rngFrom(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function hashStr(s) {
    var h = 2166136261 >>> 0;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h;
  }
  function pick(r, arr) { return arr[Math.floor(r() * arr.length)]; }
  function shuffle(r, arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function sample(r, arr, k) { return shuffle(r, arr).slice(0, k); }
  function lower(s) { return s.toLocaleLowerCase('tr-TR'); }

  // ---------- Sözlük ----------
  var COLORS = [
    { id: 'kirmizi', ad: 'kırmızı', css: '#E4574B', sq: '🟥' },
    { id: 'mavi', ad: 'mavi', css: '#3D8BEB', sq: '🟦' },
    { id: 'yesil', ad: 'yeşil', css: '#3BAF6A', sq: '🟩' },
    { id: 'sari', ad: 'sarı', css: '#F2C230', sq: '🟨' },
    { id: 'mor', ad: 'mor', css: '#9A62D8', sq: '🟪' },
    { id: 'turuncu', ad: 'turuncu', css: '#F08A2E', sq: '🟧' }
  ];
  var ANIMALS = [
    { ad: 'Tavşan', e: '🐇', abl: 'tavşandan' },
    { ad: 'Kaplumbağa', e: '🐢', abl: 'kaplumbağadan' },
    { ad: 'Kedi', e: '🐈', abl: 'kediden' },
    { ad: 'Köpek', e: '🐕', abl: 'köpekten' },
    { ad: 'Tilki', e: '🦊', abl: 'tilkiden' },
    { ad: 'Ayı', e: '🐻', abl: 'ayıdan' }
  ];
  var PLACES = ['birinci', 'ikinci', 'üçüncü', 'dördüncü', 'beşinci', 'altıncı'];
  var PEOPLE = [
    { ad: 'Ayşe', e: '👩' }, { ad: 'Mehmet', e: '👨' }, { ad: 'Zeynep', e: '👧' },
    { ad: 'Can', e: '🧒' }, { ad: 'Nene', e: '👵' }, { ad: 'Dede', e: '👴' }
  ];
  var SHIRTS = [COLORS[0], COLORS[1], COLORS[2]];
  var STORIES_KIM = [
    'Kurabiye kavanozunu kim boşalttı?',
    'Bahçedeki çiçeği kim kopardı?',
    'Kumandayı kim sakladı?',
    'Kedinin mamasını kim yedi?',
    'Duvara kim resim çizdi?',
    'Son dilim pastayı kim aldı?'
  ];
  var ITEMS = [
    { ad: 'Hazine', e: '💰' },
    { ad: 'Altın anahtar', e: '🔑' },
    { ad: 'Kayıp yüzük', e: '💍' },
    { ad: 'Doğum günü hediyesi', e: '🎁' }
  ];
  var STORIES_YARIS = [
    'Orman yarışında sıralama nasıldı?',
    'Bahçe koşusunu kim kazandı?',
    'Göl etrafındaki yarış nasıl bitti?'
  ];

  // ---------- Bulmaca türleri ----------
  // Her tür: build(r, size, adv) -> { board, worlds, clues(all), story, describe(w) }
  // İpucu: { key, text, icon, test(w) }

  function buildHazine(r, size, adv) {
    var boxes = sample(r, COLORS, size);
    var item = pick(r, ITEMS), I = item.ad, E = item.e;
    var worlds = [];
    for (var i = 0; i < size; i++) worlds.push(i);
    var loc = function (i) { return boxes[i].ad + ' kutu'; };
    var clues = [];
    boxes.forEach(function (b, i) {
      clues.push({ key: 'is' + i, strength: 3, text: I + ' ' + b.ad + ' kutuda.', icon: E + ' = ' + b.sq, test: function (w) { return w === i; } });
      clues.push({ key: 'not' + i, strength: 1, text: I + ' ' + b.ad + ' kutuda değil.', icon: E + ' ≠ ' + b.sq, test: function (w) { return w !== i; } });
      if (adv) {
        if (i > 0) clues.push({ key: 'left' + i, strength: 2, text: I + ', ' + loc(i) + 'nun solundaki kutulardan birinde.', icon: E + ' ⬅ ' + b.sq, test: function (w) { return w < i; } });
        if (i < size - 1) clues.push({ key: 'right' + i, strength: 2, text: I + ', ' + loc(i) + 'nun sağındaki kutulardan birinde.', icon: b.sq + ' ➡ ' + E, test: function (w) { return w > i; } });
        clues.push({ key: 'nb' + i, strength: 2, text: I + ', ' + loc(i) + 'nun hemen yanındaki kutuda.', icon: E + ' ↔ ' + b.sq, test: function (w) { return Math.abs(w - i) === 1; } });
        for (var j = i + 1; j < size; j++) (function (j) {
          clues.push({ key: 'or' + i + '_' + j, strength: 2, text: I + ' ya ' + b.ad + ' ya da ' + boxes[j].ad + ' kutuda.', icon: E + ' = ' + b.sq + ' / ' + boxes[j].sq, test: function (w) { return w === i || w === j; } });
        })(j);
      }
    });
    if (adv && size >= 4) {
      clues.push({ key: 'edge', strength: 2, text: I + ' en kenardaki kutulardan birinde.', icon: E + ' ▕ ▏', test: function (w) { return w === 0 || w === size - 1; } });
    }
    return {
      type: 'hazine',
      story: I + ' hangi kutuda?',
      item: item,
      board: { item: item, boxes: boxes.map(function (b) { return { ad: b.ad, css: b.css, sq: b.sq }; }) },
      worlds: worlds,
      clues: clues,
      describe: function (w) { return I + ' ' + boxes[w].ad + ' kutudaydı.'; }
    };
  }

  function permutations(n) {
    var out = [];
    var a = [];
    for (var i = 0; i < n; i++) a.push(i);
    (function rec(k) {
      if (k === n) { out.push(a.slice()); return; }
      for (var i = k; i < n; i++) {
        var t = a[k]; a[k] = a[i]; a[i] = t;
        rec(k + 1);
        t = a[k]; a[k] = a[i]; a[i] = t;
      }
    })(0);
    return out;
  }

  function buildYaris(r, size, adv) {
    var animals = sample(r, ANIMALS, size);
    // dünya: order[yer] = hayvan; pos[hayvan] = yer
    var worlds = permutations(size).map(function (order) {
      var pos = [];
      order.forEach(function (a, p) { pos[a] = p; });
      return { order: order, pos: pos };
    });
    var clues = [];
    animals.forEach(function (a, i) {
      for (var p = 0; p < size; p++) (function (p) {
        var last = p === size - 1;
        var placeWord = last ? 'sonuncu' : PLACES[p];
        clues.push({ key: 'pl' + i + '_' + p, strength: 3, text: a.ad + ' ' + placeWord + ' oldu.', icon: a.e + ' = ' + (p + 1), test: function (w) { return w.pos[i] === p; } });
        clues.push({ key: 'np' + i + '_' + p, strength: 1, text: a.ad + ' ' + placeWord + ' olmadı.', icon: a.e + ' ≠ ' + (p + 1), test: function (w) { return w.pos[i] !== p; } });
      })(p);
      animals.forEach(function (b, j) {
        if (i === j) return;
        clues.push({ key: 'bf' + i + '_' + j, strength: 2, text: a.ad + ', ' + b.abl + ' önce bitirdi.', icon: a.e + ' önce ' + b.e, test: function (w) { return w.pos[i] < w.pos[j]; } });
        if (adv && i < j) {
          clues.push({ key: 'adj' + i + '_' + j, strength: 2, text: a.ad + ' ile ' + lower(b.ad) + ' art arda bitirdi.', icon: a.e + b.e + ' yan yana', test: function (w) { return Math.abs(w.pos[i] - w.pos[j]) === 1; } });
        }
      });
    });
    return {
      type: 'yaris',
      story: pick(r, STORIES_YARIS),
      board: { animals: animals.map(function (a) { return { ad: a.ad, e: a.e }; }) },
      worlds: worlds,
      clues: clues,
      describe: function (w) { return 'Sıralama: ' + w.order.map(function (a) { return animals[a].ad; }).join(', ') + '.'; }
    };
  }

  function buildKim(r, size, adv) {
    var ppl = sample(r, PEOPLE, size).map(function (p) {
      return { ad: p.ad, e: p.e, hat: r() < 0.5, glasses: r() < 0.5, shirt: pick(r, SHIRTS) };
    });
    var worlds = [];
    for (var i = 0; i < size; i++) worlds.push(i);
    var clues = [];
    function attrClue(key, text, icon, fn, strength) {
      // tüm şüphelilerde aynı sonucu veren özellik ipucu işe yaramaz
      var vals = ppl.map(fn);
      if (vals.every(function (v) { return v === vals[0]; })) return;
      clues.push({ key: key, strength: strength, text: text, icon: icon, test: function (w) { return fn(ppl[w]); } });
    }
    attrClue('hat1', 'Suçlu şapkalı.', '🕵️ 🎩', function (p) { return p.hat; }, 2);
    attrClue('hat0', 'Suçlu şapkasız.', '🕵️ 🚫🎩', function (p) { return !p.hat; }, 2);
    attrClue('gl1', 'Suçlu gözlüklü.', '🕵️ 👓', function (p) { return p.glasses; }, 2);
    attrClue('gl0', 'Suçlu gözlüksüz.', '🕵️ 🚫👓', function (p) { return !p.glasses; }, 2);
    SHIRTS.forEach(function (c) {
      attrClue('c1' + c.id, 'Suçlu ' + c.ad + ' giyiyor.', '🕵️ 👕' + c.sq, function (p) { return p.shirt === c; }, 2);
      attrClue('c0' + c.id, 'Suçlu ' + c.ad + ' giymiyor.', '🕵️ 👕≠' + c.sq, function (p) { return p.shirt !== c; }, 1);
    });
    ppl.forEach(function (p, i) {
      clues.push({ key: 'np' + i, strength: 1, text: 'Suçlu ' + p.ad + ' değil.', icon: '🕵️ ≠ ' + p.e, test: function (w) { return w !== i; } });
      if (adv) clues.push({ key: 'is' + i, strength: 3, text: 'Suçlu ' + p.ad + '.', icon: '🕵️ = ' + p.e, test: function (w) { return w === i; } });
    });
    return {
      type: 'kim',
      story: pick(r, STORIES_KIM),
      board: { people: ppl.map(function (p) { return { ad: p.ad, e: p.e, hat: p.hat, glasses: p.glasses, shirt: { ad: p.shirt.ad, css: p.shirt.css } }; }) },
      worlds: worlds,
      clues: clues,
      describe: function (w) { return 'Suçlu ' + ppl[w].ad + ' idi.'; }
    };
  }

  var BUILDERS = { hazine: buildHazine, yaris: buildYaris, kim: buildKim };

  // ---------- Çözücü ----------
  function falseCounts(worlds, clues) {
    return worlds.map(function (w) {
      var c = 0;
      for (var i = 0; i < clues.length; i++) if (!clues[i].test(w)) c++;
      return c;
    });
  }
  // Geçerli mi? { ok, world index }
  function check(worlds, clues, L) {
    var fc = falseCounts(worlds, clues);
    var hit = -1;
    for (var i = 0; i < fc.length; i++) {
      if (fc[i] < L) return { ok: false };
      if (fc[i] === L) { if (hit >= 0) return { ok: false }; hit = i; }
    }
    return hit >= 0 ? { ok: true, world: hit } : { ok: false };
  }
  function isMinimal(worlds, clues, L, liarSet) {
    // Doğru ipuçlarından biri çıkarılınca bulmaca hâlâ tek çözümlü kalıyorsa o ipucu gereksiz.
    for (var i = 0; i < clues.length; i++) {
      if (liarSet[i]) continue;
      var rest = clues.filter(function (_, j) { return j !== i; });
      if (check(worlds, rest, L).ok) return false;
    }
    return true;
  }

  // Birbirinin tam tersi olan ipuçları aynı gruba düşer (ör. "kırmızı kutuda" / "kırmızı kutuda değil")
  function groupOf(key) {
    var m;
    if ((m = /^(?:is|not|np)(\d+)$/.exec(key))) return 'x' + m[1];
    if ((m = /^(?:pl|np)(\d+_\d+)$/.exec(key))) return 'p' + m[1];
    if ((m = /^(hat|gl)[01]$/.exec(key))) return m[1];
    if ((m = /^c[01](.+)$/.exec(key))) return 'c' + m[1];
    if ((m = /^bf(\d+)_(\d+)$/.exec(key))) return 'b' + Math.min(+m[1], +m[2]) + '_' + Math.max(+m[1], +m[2]);
    return key;
  }
  function hasNegPair(clues) {
    var seen = {};
    for (var i = 0; i < clues.length; i++) {
      var g = groupOf(clues[i].key);
      if (seen[g]) return true;
      seen[g] = true;
    }
    return false;
  }

  // ---------- Mod ayarları ----------
  var MODES = {
    minik: { ad: 'Minik Dedektif', yas: '4–7 yaş', levels: 30, sorgula: 2, tts: true, big: true },
    dedektif: { ad: 'Dedektif', yas: '8–12 yaş', levels: 40, sorgula: 2 },
    usta: { ad: 'Usta', yas: '13+ yaş', levels: 50, sorgula: 1, timer: true },
    sakin: { ad: 'Sakin Mod', yas: 'Her yaş, büyük yazı', levels: 40, sorgula: 2, big: true, calm: true }
  };
  var TYPE_ORDER = ['hazine', 'kim', 'yaris'];

  function levelParams(mode, n) {
    // n: 1'den başlar
    var type = TYPE_ORDER[(n - 1) % 3];
    var p = { type: type, liars: 1, adv: false };
    if (mode === 'minik') {
      p.clues = 3; p.size = 3; p.adv = false;
    } else if (mode === 'dedektif') {
      p.clues = n <= 12 ? 4 : 5;
      p.size = n <= 6 ? 3 : 4;
      p.adv = n > 12;
      p.noNeg = n > 12;
    } else if (mode === 'usta') {
      p.adv = true;
      p.noNeg = true;
      p.size = n <= 15 ? 4 : 5;
      p.clues = n <= 15 ? 5 : 6;
      if (n > 30) { p.liars = 2; p.clues = 7; }
    } else { // sakin
      p.adv = n > 10;
      p.noNeg = n > 10;
      p.size = 4;
      p.clues = n <= 20 ? 4 : 5;
    }
    if (type === 'yaris') {
      // sıralama bulmacalarında dünya sayısı hızla artar, boyutu kıs
      p.size = Math.min(p.size, mode === 'usta' && n > 20 ? 5 : 4);
      if (mode === 'minik') p.size = 3;
    }
    return p;
  }

  // ---------- Üreteç ----------
  function generate(params, seed) {
    var r = rngFrom(seed);
    var size = params.size;
    for (var shrink = 0; shrink < 3; shrink++) {
      var built = BUILDERS[params.type](r, size, params.adv);
      var res = tryBuild(r, built, params.clues, params.liars, 900, params.noNeg);
      if (res) return res;
      if (size > 3) size--; // olmadıysa küçült
    }
    throw new Error('Seviye üretilemedi');
  }

  function tryBuild(r, built, K, L, attempts, noNeg) {
    var worlds = built.worlds;
    var best = null;
    for (var t = 0; t < attempts; t++) {
      var target = Math.floor(r() * worlds.length);
      var w = worlds[target];
      var trues = [], falses = [];
      built.clues.forEach(function (c) { (c.test(w) ? trues : falses).push(c); });
      if (falses.length < L || trues.length < K - L) continue;
      // Yalancı ipucu tercihen "güçlü" bir iddia olsun (daha ilginç)
      var liarPool = falses.filter(function (c) { return c.strength >= 2; });
      if (liarPool.length < L) liarPool = falses;
      var liars = sample(r, liarPool, L);
      var honest = sample(r, trues, K - L);
      // aynı anahtar tekrarlanmasın
      var clues = shuffle(r, liars.concat(honest));
      if (noNeg && hasNegPair(clues)) continue;
      var res = check(worlds, clues, L);
      if (!res.ok || res.world !== target) continue;
      var liarSet = clues.map(function (c) { return liars.indexOf(c) >= 0; });
      var minimal = isMinimal(worlds, clues, L, liarSet);
      var cand = { clues: clues, liarSet: liarSet, target: target };
      if (minimal) return finish(built, cand, L);
      if (!best) best = cand;
    }
    return best ? finish(built, best, L) : null;
  }

  function finish(built, cand, L) {
    var worlds = built.worlds;
    var clues = cand.clues;
    var w = worlds[cand.target];
    // çelişen çiftler: hiçbir dünyada ikisi birden doğru olamaz ve biri yalancı
    var pairs = [];
    for (var i = 0; i < clues.length; i++) for (var j = i + 1; j < clues.length; j++) {
      if (!(cand.liarSet[i] || cand.liarSet[j])) continue;
      var both = worlds.some(function (x) { return clues[i].test(x) && clues[j].test(x); });
      if (!both) pairs.push([i, j]);
    }
    var labels = 'ABCDEFGH';
    return {
      type: built.type,
      story: built.story,
      board: built.board,
      liars: L,
      clues: clues.map(function (c, i) { return { id: labels[i], text: c.text, icon: c.icon, lie: cand.liarSet[i] }; }),
      answer: built.type === 'yaris' ? w.order.slice() : w,
      explanation: built.describe(w),
      conflictPairs: pairs
    };
  }

  function levelSeed(mode, n) { return hashStr('yalanci-ipucu/v1/' + mode + '/' + n); }

  function getLevel(mode, n) {
    var params = levelParams(mode, n);
    var lvl = generate(params, levelSeed(mode, n));
    lvl.mode = mode; lvl.n = n;
    return lvl;
  }

  function dailyKey(date) {
    var d = date || new Date();
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
  }
  // Günün bulmacası: her modda aynı tür ve hikâye tohumu, zorluk moda göre
  function getDaily(mode, date) {
    var key = dailyKey(date);
    var h = hashStr('gunluk/' + key);
    var type = TYPE_ORDER[h % 3];
    var base = { minik: 3, dedektif: 10, usta: 20, sakin: 15 }[mode];
    var params = levelParams(mode, base);
    params.type = type;
    var lvl = generate(params, hashStr('gunluk/' + key + '/' + mode));
    lvl.mode = mode; lvl.n = 0; lvl.daily = key;
    return lvl;
  }

  var api = { MODES: MODES, getLevel: getLevel, getDaily: getDaily, dailyKey: dailyKey, levelParams: levelParams, _check: check };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.YIEngine = api;
})(this);
